package com.example.fragement;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void onclick1(View v) {
		//��fragment01�Ľ�����ʾ��֡������ȥ
		//����fragment����
		Fragement01 fg1 = new Fragement01();
		//��ȡFragment������
		FragmentManager fm = getFragmentManager();
		//��Fragment��������������
		FragmentTransaction ft = fm.beginTransaction();
		//���ݺ�֡���ְ�
		ft.replace(R.id.f1, fg1);
		//�ύ
		ft.commit();

	}

	public void onclick2(View v) {
		//
		Fragement02 fg2 = new Fragement02();
		FragmentManager fm = getFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		ft.replace(R.id.f1, fg2);
		ft.commit();

	}

	public void onclick3(View v) {
		//
		Fragement03 fg3 = new Fragement03();
		FragmentManager fm = getFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		ft.replace(R.id.f1, fg3);
		ft.commit();

	}
}
