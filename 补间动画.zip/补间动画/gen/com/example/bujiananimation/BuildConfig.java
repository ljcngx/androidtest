/** Automatically generated file. DO NOT MODIFY */
package com.example.bujiananimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}