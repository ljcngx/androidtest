package com.example.bujiananimation;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private ImageView iv;
	
	private TranslateAnimation ta ;
	private RotateAnimation ra;
	private AlphaAnimation aa;
	private ScaleAnimation sa;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		iv = (ImageView) findViewById(R.id.iv);
	}
	//ƽ��
	public void translate(View v){
		//����ƽ�Ƶ�x��y���꿪ʼλ�õ�����λ�ã�
		ta= new TranslateAnimation(0, 100, 0, 100);
		//���ö���ʱ��
		ta.setDuration(2000);
		//�����ظ�����
		ta.setRepeatCount(1);
		//�����ظ�ģʽ
		ta.setRepeatMode(Animation.REVERSE);
		//��������
		iv.startAnimation(ta);
	}
	//����
	public void scale(View v){
//		sa = new ScaleAnimation(0.5f, 2, 0.1f, 3);
//		sa = new ScaleAnimation(0.5f, 2, 0.1f, 3, iv.getWidth()/2, iv.getHeight()/2);
		sa = new ScaleAnimation(0.5f, 2, 0.1f, 3, Animation.RELATIVE_TO_SELF,0.5f,  Animation.RELATIVE_TO_SELF,0.5f);
		sa.setDuration(2000);
		sa.setRepeatMode(Animation.REVERSE);
		sa.setRepeatCount(1);
		sa.setFillAfter(true);
		iv.startAnimation(sa);
	}
	//͸��
	public void alpha(View v){
		aa = new  AlphaAnimation(0, 0.3f);
		aa.setDuration(2000);
		aa.setRepeatCount(1);
		iv.startAnimation(aa);
	}
	//��ת
	public void rotate(View v){
//		ra = new RotateAnimation(20, 180,iv.getWidth()/2, iv.getHeight()/2);
		ra = new RotateAnimation(10, 360,Animation.RELATIVE_TO_SELF,0.5f,  Animation.RELATIVE_TO_SELF,0.5f);
		ra.setDuration(2000);
		ra.setRepeatCount(1);
		ra.setRepeatMode(Animation.RESTART);
		iv.startAnimation(ra);
	}
	//һ��������ǰ��ǰ��ķ��������ù�
	public void fly(View v) {
		AnimationSet set  = new AnimationSet(false);
		set.addAnimation(ta);
		set.addAnimation(sa);
		set.addAnimation(aa);
		set.addAnimation(ra);
		iv.startAnimation(set);
	}
	
}
