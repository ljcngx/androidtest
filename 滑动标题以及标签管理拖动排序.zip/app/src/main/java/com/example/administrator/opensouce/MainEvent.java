package com.example.administrator.opensouce;

/**
 * Created by Administrator on 2016/4/29 0029.
 */
public class MainEvent {
    public MainEvent() {

    }
}
