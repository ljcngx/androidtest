package com.example.administrator.opensouce;

/**
 * Created by Administrator on 2016/4/29 0029.
 */
public class Top {
    public int kId;
    public String kName;
    public int keys_Isshow;

    public Top(int kId, String kName, int keys_Isshow) {
        this.kId = kId;
        this.kName = kName;
        this.keys_Isshow = keys_Isshow;
    }
}
